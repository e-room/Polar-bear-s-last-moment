/**
 * Copyright (c) 2022 ZEP Co., LTD
 */
const polarBear = App.loadSpritesheet('polar-bear.png', 240, 270);
const polarBearTwo = App.loadSpritesheet('polar-bear-2.png', 240, 270);
const DOWN_SPEED = 10;
let down_speed = 1;
App.onLeavePlayer.Add(function (p) {}); // 플레이어가 해당 맵에 들어왔을 때 처리

App.onJoinPlayer.Add(function (p) {
  p.spawnAt(32, 20, 2);
  p.sprite = polarBear;
  p.moveSpeed = 20;
  p.tag = {
    alive: true,
    ready: false
  };
  p.title = 'READY!';
  p.sendUpdated();
  setTimeout(function () {
    p.tag.ready = true;
    p.title = 'SAVE ME!!';
    p.sendUpdated();
  }, 4000);
});
App.addOnKeyDown(88, function (p) {
  // 왼쪽 화살표
  if (!p.tag.ready) return;
  p.spawnAt(p.tileX, p.tileY - 1, 2);
});
App.onStart.Add(function () {});
App.onUpdate.Add(function (dt) {
  App.showCenterLabel("Press 'x' to save the polar bear!");
  down_speed++;
  let players = App.players;
  players.forEach(player => {
    if (player.tileY >= Map.height) {
      player.tag.alive = false;
      player.title = `I'll be back..`;
      player.sendUpdated();
    }
  });

  if (down_speed >= DOWN_SPEED) {
    down_speed = 1;
    players.forEach(player => {
      if (!player.tag.ready) return;
      if (!player.tag.alive) return;
      if (player.sprite == polarBear) player.sprite = polarBearTwo;else player.sprite = polarBear;
      player.sendUpdated();
      player.spawnAt(player.tileX, player.tileY + 1, 2);
    });
  }
});